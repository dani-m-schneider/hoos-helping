[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/bknTyRar)
# Django Project

Name: Shane Kim, Tommy Le, Mohit Maineli, Daniela Schnieder, Julia Tan

Computing ID: mse9cr, tl3uk, fys3bq, uqf3cg, qvp8hy

This is a project management application. Sign in with a valid Google login and create/join community service projects. 
You can create projects and add collaborators, upload documents, and keep track of tasks that need to be completed. You can then share your project on social media!
You can request to join projects if interested in a project to view more details.
You can manage projects such as add, join, and delete.
You can also chat with other project collaborators in a project chat.
There is a calendar view to see when your projects are active (time/date). 

We hope you enjoy!
