urlpatterns = [
    path('', views.index, name='index'),
    # other URL patterns
]